/*================================================================= <AUTO GENERATED FILE/> ==================================================================
this file was copied from net-extensions/for_netcore9 project please note that changes applied to this file will be overwritten without warning 
and work will be lost. Everytime the codebase changes in this project the api image is recopied and altered to
fit the implementation.
===============================================================================================================================================================

    original repository uri address: https://github.com/ejjonatah/net-extensions
    The MIT License (MIT)   Copyright (c) James Jonatah and Contributors    All rights reserved.
    
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the `"Software`"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED `"AS IS`", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    
         ___         __         _            
        / \ \       / /        | |              
       / / \ \     / _ __   ___| |___  _____    |    /\/etxs (.NET Extensions)
      / /   \ \   / | '_ \ / _ | __\ \/ / __|   
     / /     \ \ / /| | | |  __| |_ >  <\__ \   |    Goiania - 2025-03-19
    /_/       \_/_/ |_| |_|\___|\__/_/\_|___/   |    @ejjonatah
    -------------------------------------------------------

    ===============================================================================================================================================================
    Implementation helpers and extension classes source file. A set of features and framework members aliases focused in improving development speed               
    and code readability. How? defining contextualized named-constants instead of magicnumbers, also variable based type arguments for some large usage operations 
    in dotnet coding, also provide easy access to static instances very important services to well usage of the framework's                                        
    kit, e.g MemoryPool(s),  UTF8 encoding, CultureInfo(s) and much more                                                                                           
    =============================================================================================================================================================*/

// we suppress this warnings due to the following reasons
// IDE0005: these global using directives are intended to be used by the developer at implementation phase
// RCS1110: this is NOT a library, its a shared, globally imported file an actual namespace is not necessarily
// IDE1006: some of the definitions in this file are intended to be used like a keyword, so we mantain lowercase
// RCS1043: we allow users to extend classes in their own projects by making them partial
#pragma warning disable IDE0005, RCS1110, IDE1006, RCS1043, S3903, S3963, S3358, S3236

#nullable enable
//! /!\ this project requires global 'using' importations to be defined by the consumer project
//! an example of these importations can be found in this "props" file online gist
//! gist.github.com/ejjonatah/3e01b67d264975919dfcd76e4c95f3be/raw/e7bc903c1c103697235dcb40ce8a5b6a2e6fa0a0/dotnet_imports.props

#if !PROPS_PRESENT 
#error !!! /!\ MISSING FILES ERROR !!!: please contact @ejjonatah to get te apropriate .props files to this project
#endif
using global::System.Collections.Generic;using static Netxs5DE50C8G;using Ejjons.NetExtensions.Core9;using System.Diagnostics.CodeAnalysis;using global::System;using global::System.Diagnostics;using global::System.IO;using global::System.Linq;using global::System.Net.Http;using global::System.Threading;using global::System.Threading.Tasks;using System.Buffers;using System.ComponentModel;using System.Diagnostics;using System.Globalization;using System.Runtime.CompilerServices;using System.Runtime.InteropServices;using System.Text;/// <summary>This <see langword="class"/> is used statically as globally via  <see langword="using static"/>  expression within this project or importer projects. All members in here exists everywhere simultaneously</summary>
[NoDebug][NoWarn("","S3903",Justification="Global importation scope")][NoWarn("","RCS1043",Justification="Global importation scope")][NoWarn("","RCS1110",Justification="Global importation scope")]static partial class Netxs5DE50C8G{internal const bool AS_MUTABLE=false;internal const bool AS_READONLY=true;internal const string AS_STRNQ="{ToString(),nq}";internal const string AS_DBGMTHOD="{debugDisplay(),nq}";internal const string AS_PUBMTHOD="{AsHumanExpression(),nq}";internal const string SIGNALIZE_DEFAULT_ISTANCE="<default>$";internal const string SIGNALIZE_DISPOSD_INSTANCE="/!\\ _disposed";/// <summary>Max reasonable size for a <see cref="byte"/>[ ] array rental in the  <c><see cref="System.Buffers.ArrayPool{T}.Shared"/></c>  from the <i>.NET</i> <see langword="global"/> shared pool</summary>
/// <value><c><typeparamref name="_65535"/></c></value>
internal const ushort MAX_RENTABLE_SIZE=ushort.MaxValue;/// <summary>An integer value that represents a large allocation on the stack, for a <see langword="stackalloc"/> expression</summary>
/// <value><inheritdoc cref="BIGALOC"/></value>
internal const ushort LARGE_ONSTACK_SIZE=BIGALOC;/// <summary>An integer value that represents a reasonably small allocation on the stack, for a <see langword="stackalloc"/> expression</summary>
/// <value><inheritdoc cref="SMALLOC"/></value>
internal const ushort SMALL_ONSTACK_SIZE=SMALLOC;/// <summary>Is set to the definition in <see cref="byte"/>(s) of pointer instance's size, a <see langword="const"/> alternative for nint.Size. This is platform dependent</summary>
/// <value><inheritdoc cref="CPU_ARCHITECTURE"/> <c>  <typeparamref name="_8"/></c></value>
internal const byte CPUPTR_SIZE=CPU_ARCHITECTURE/8;/// <summary>Generic labeling for the  <c>\0</c>  expression as a <see cref="byte"/> in UTF-8</summary>
internal const byte u8ENDOF_STRING=(byte)'\0';/// <summary>Generic labeling for the     expression as a <see cref="byte"/> in UTF-8</summary>
internal const byte u8EMPTY_SPACE=(byte)' ';/// <summary>Generic labeling for the  <c>\n</c>  expression as a <see cref="byte"/> in UTF-8</summary>
internal const byte u8NEW_LINE=(byte)'\n';/// <summary>Generic labeling for the  <c>\0</c>  expression as a <see cref="char"/> in UTF-16</summary>
internal const char ENDOF_STRING='\0';/// <summary>Generic labeling for the     expression as a <see cref="char"/> in UTF-16</summary>
internal const char EMPTY_SPACE=' ';/// <summary>Generic labeling for a non-existent index integer</summary>
internal const short NOT_FOUND=-1;/// <summary>Generic labeling for the  <c>\n</c>  expression as a <see cref="char"/> in UTF-16</summary>
internal const char NEW_LINE='\n';/// <summary>Generic labeling for a number 1 take operation</summary>
internal const byte SINGLE_ITEM=1;/// <summary>Generic labeling for the first index of an array</summary>
internal const byte FROM_START=0;/// <summary>Generic labeling for a failed  Try  method pattern result</summary>
internal const bool FAILED=false;/// <summary>Generic labeling for an empty  <see cref="System.Collections.IEnumerator.MoveNext()"/>  of an IEnumerator</summary>
internal const bool EMPTY=false;/// <summary>Generic labeling for a zeroed return result</summary>
internal const byte ENDED=0;internal const int FIRST_ELEMENT=0;internal const int EMPTIED=0;internal const DebuggerBrowsableState NO_DEBUG=DebuggerBrowsableState.Never;internal const EditorBrowsableState VS_HIDDEN=EditorBrowsableState.Never;internal const MethodImplOptions INLINE=MethodImplOptions.AggressiveInlining;internal const MethodImplOptions FCALL=MethodImplOptions.NoInlining;internal const LayoutKind SEQC=LayoutKind.Sequential;internal const LayoutKind AUTO=LayoutKind.Auto;/// <summary>Shared <see langword="static global"/> instance of <see cref="CultureInfo"/> for Brazilian Portuguese. Use this instead of <see langword="new"/> instance expression. Used for input/output formatting</summary>
internal static readonly CultureInfo pt_Br=CultureInfo.GetCultureInfo("pt-Br");/// <summary>Shared <see langword="static global"/> instance of <see cref="CultureInfo"/> for British English. Use this instead of <see langword="new"/> instance expression. Used for input/output formatting</summary>
internal static readonly CultureInfo en_Uk=CultureInfo.GetCultureInfo("en-Uk");/// <summary>Shared <see langword="static global"/> instance of <see cref="CultureInfo"/> for American English. Use this instead of <see langword="new"/> instance expression. Used for input/output formatting</summary>
internal static readonly CultureInfo en_Us=CultureInfo.InvariantCulture;/// <summary>Shared <see langword="static global"/> instance of <see cref="Encoding"/> of UTF8, short term for <see cref="Encoding.UTF8"/></summary>
internal static readonly Encoding uTF8=Encoding.UTF8;/// <summary>The choosen memory pool. Might be  <i>.NET shared</i>  <see langword="global"/> memory pool from <see cref="System.Buffers.ArrayPool{T}.Shared"/><br/>
/// or <see langword="null"/> if it was specified not to use a shared pool when  <c>DONT_SHARE_POOL</c>  arg is present<br/>
/// or <see langword="new"/> internally created one if specified so when  <c>AVOID_SHARED_POOL</c>  arg is present <br/>
/// </summary>
internal static readonly ArrayPool<byte>?mempool;internal const bool IS_DEBUG=
#if DEBUG
true;

#else
false;
#endif

#if TARGET_64BIT
    /// <value><c><typeparamref name="_64"/></c></value>


#else
/// <value><c><typeparamref name="_32"/></c></value>

#endif
const byte CPU_ARCHITECTURE
#if TARGET_64BIT
        = 64;

#else
=32;
#endif

#if TARGET_64BIT
    /// <value><c><typeparamref name="_512"/></c></value>


#else
/// <value><c><typeparamref name="_256"/></c></value>

#endif
const ushort SMALLOC
#if TARGET_64BIT
        = 512;

#else
=256;
#endif

#if TARGET_64BIT
    /// <value><c><typeparamref name="_4096"/></c></value>


#else
/// <value><c><typeparamref name="_1024"/></c></value>

#endif
const ushort BIGALOC
#if TARGET_64BIT
        = 4096;

#else
=1024;
#endif
const bool SYMBOL_DONTSHAREPOOL
#if !DEBUG && DONT_SHARE_POOL
        = true;

#else
=false;
#endif
const bool SYMBOL_AVOIDSHAREDPOOL
#if !DEBUG && AVOID_SHARED_POOL
        = true;

#else
=false;
#endif
internal static readonly CultureInfo?cmdArgsCulture
#if NETXS_PTBR
        = pt_Br;

#elif NETXS_ENUK
        = en_Uk;

#elif NETXS_ENUS
        = en_Us;

#elif DEBUG
=Environment.GetCommandLineArgs()switch{var args when args.Contains("NETXS_PTBR")=>pt_Br,var args when args.Contains("NETXS_ENUK")=>en_Uk,var args when args.Contains("NETXS_ENUS")=>en_Us,_=>null};
#else
        = null;

#endif
static Netxs5DE50C8G(){var args=Environment.GetCommandLineArgs();mempool=args.Contains("DONT_SHARE_POOL")||SYMBOL_DONTSHAREPOOL?null:args.Contains("AVOID_SHARED_POOL")||SYMBOL_AVOIDSHAREDPOOL?ArrayPool<byte>.Create(MAX_RENTABLE_SIZE,CPU_ARCHITECTURE):ArrayPool<byte>.Shared;}/// <summary>
/// either <see cref="byte"/>,
/// <see cref="sbyte"/>,   <see cref="short"/>,
/// <see cref="ushort"/>,  <see cref="int"/>,
/// <see cref="uint"/>,    <see cref="long"/>,
/// <see cref="ulong"/>,   <see cref="float"/>,
/// <see cref="double"/>,
/// <br/> or
/// <see cref="decimal"/>, <see cref="object"/>,   <see cref="bool"/>,
/// <see cref="char"/>,    <see cref="string"/>,
/// <see langword="nint"/>,<see langword="nuint"/>
/// <br/>
/// or <see cref="Type.FullName"/> when (<paramref name="fullName"/>: <see langword="true"/>)
/// <br/>
/// else <see cref="Type"/>.Name
/// </summary>
public static string nameofAlias<T>([Null]in T _0,bool fullName=false){return nameofAlias<T>(fullName);}/// <inheritdoc cref="nameofAlias{T}(bool)"/>
public static string nameofAlias<T>(bool fullName=false){var valueType=typeof(T);var valueTypeName=valueType.Name;return valueTypeName switch{"Byte"=>"byte","SByte"=>"sbyte","Int16"=>"short","UInt16"=>"ushort","Int32"=>"int","UInt32"=>"uint","Int64"=>"long","UInt64"=>"ulong","Single"=>"float","Double"=>"double","Decimal"=>"decimal","Boolean"=>"bool","Char"=>"char","String"=>"string","IntPtr"=>"nint","UIntPtr"=>"nuint","Object"=>"object",_=>fullName?typeof(T).FullName??valueTypeName:valueTypeName,};}/// <summary>
/// Calcuates the binary-size of a ( <typeparamref name="T"/> ) instance through <see cref="Mrshal">Marshal</see> for classes and <see cref="Unsfe">Unsafe</see> for structures
/// </summary>
public static ushort msizeof<T>(){int result=!NetRHelpers.IsReferenceOrContainsReferences<T>()?Unsfe.SizeOf<T>():Mrshal.SizeOf<T>();const string str="No type should have a size bigger than ushort.MaxValue: 65535";Debug.Assert(ushort.MaxValue>=result,message:str);return(ushort)result;}}namespace Ejjons.NetExtensions{[Eval("( click through to evaluate results. )")]struct EvaluationBarrier:IEnumerator<object?>,IEnumerable<object?>{[View(NO_DEBUG)]bool not_evaluated=true;[View(NO_DEBUG)]readonly Func<IEnumerable<object?>>fetch;[View(NO_DEBUG)]public object?Current{readonly get;private set;}[Skip]public EvaluationBarrier(Func<IEnumerable<object?>>fetch):this(){this.fetch=fetch;}[Skip]readonly System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator(){return this;}[Skip]public readonly IEnumerator<object?>GetEnumerator(){return this;}[Skip]public readonly void Dispose(){}[Skip]public readonly void Reset(){}[Skip]public bool MoveNext(){if(not_evaluated){var fetcher=fetch().GetEnumerator();bool movingNext=fetcher.MoveNext();if(movingNext){Current=fetcher.Current;}not_evaluated=false;return movingNext;}return false;}}}namespace Ejjons.NetExtensions.Core9{/// <summary> 
/// Provides helper methods for fast cutting-off code execution (conditionally) through throwing exceptions, differentiating from the throw helpers, this 
/// class's methods are more focused on parameter's values checking 
/// </summary> 
/// <remarks> 
/// although this adds more function calls to the sequence, it prevents the compiler from caching the instance creation (of 
/// the exception) event though it wouldn't actually throw due to no exceptional error conditions being match 
/// </remarks> 
[Skip]
#if NETXS_ASPUBLIC
public
#endif
static class ParametersValuesValidationHelpers{}}namespace Ejjons.NetExtensions.Core9{
#if NETXS_ASPUBLIC
public
#endif
static class StringLikeExtensions{
#if NETXS_ASPUBLIC
public
#endif
 static string Copy(string str){return string.Concat(str.ToArray());}}}namespace Ejjons.NetExtensions.Core9{/// <summary>Provides helper methods for fast cutting-off code execution (conditionally) through throwing exceptions </summary> 
/// <remarks> although this adds more function calls to the sequence, it prevents the compiler from caching the instance creation (of 
/// the exception) event though it wouldn't actually throw due to no exceptional error conditions being match </remarks> 
#if NETXS_NODEBUG
[NoDebug]
#endif

#if NETXS_ASPUBLIC
public
#endif
static class ThrowingHelpers{}}

