/*================================================================= <AUTO GENERATED FILE/> ==================================================================
this file was copied from moldo-convention/for_csharp project please note that changes applied to this file will be overwritten without warning 
and work will be lost. Everytime the codebase changes in this project the api image is recopied and altered to
fit the implementation.
=============================================================================================================================================================

    original repository uri address: https://github.com/ejjonatah/moldo-convention
    The MIT License (MIT)   Copyright (c) James Jonatah and Contributors    All rights reserved.
    
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the `"Software`"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.
    
    THE SOFTWARE IS PROVIDED `"AS IS`", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    
     _____     _   _        | Data schema serialization/transmission contract
    |     |___| |_| |___    
    | | | | . | | . | . |   | Goiania - 2026
    |_|_|_|___|_|___|___|   | @ejjonatah
    
    This is a convention file to deal with objects model design through a contract knowledge system. The objective of this 
    system is enabling multi platform applications to communicate with each other using the same language. The type system here is 
    not entirely dynamic but there might be new extra columns to deal with without recompiling the code
    
    Widely used intertwined integration types
        This are the commonly used types among different platforms for integrated applications and may be added as overloading for 
        methods specialized on dealing with each data type possibly received from a transmission
    
    based upon: u8
                                         type hits | suggestions
    abstract type       value        /\/  .NET      SQL         TS        size
       financial    | 01010000 | --  80   decimal   money       Number     16
       rational     | 00100001 | --  33   float     float(2)    Number     04
       integral     | 01000011 | --  67   int       int         Number     04
       cardinal     | 00000111 | --  07   long      bigint      Number     08
       temporal     | 00001111 | --  15   DateTime   DateTime   Date       08
       relationa    | 00011110 | --  30   Guid      identifier  String     16
       textual      | 01111101 | --  125  String    varchar*    String     ??

    The above values represent different situations describing a specific value-type. Mos of these should have specific classes representing them in
    each environment. 
    
    Const well known value Constraints
        The data about the transmitted should follow a rule contract before sending. This contract should be centralized in a particular
        provider, applications may store this locally but it must be provided externally.*/

//! /!\ this project requires global 'using' importations to be defined by the consumer project
//! an example of these importations can be found in this "props" file online gist
//! gist.github.com/ejjonatah/3e01b67d264975919dfcd76e4c95f3be/raw/e7bc903c1c103697235dcb40ce8a5b6a2e6fa0a0/dotnet_imports.props
//! also this project requires the presence of the github.com/ejjonatah/net-extensions/src/for_netcore9 library as an dependency 
#if !PROPS_PRESENT 
#error !!! /!\ MISSING FILES ERROR !!!: please contact @ejjonatah to get te apropriate .props files to this project
#endif
using global::System.Collections.Generic;using Ejjons.MoldoNet;using global::System;using global::System.Diagnostics;using global::System.IO;using global::System.Linq;using global::System.Net.Http;using global::System.Threading;using global::System.Threading.Tasks;namespace Ejjons.MoldoNet{
#if MOLDO_ASPUBLIC
public
#endif
enum RawValueConstraints{}}

